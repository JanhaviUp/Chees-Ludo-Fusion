const height = 10;
const width = 10;
let players = [];
let currentPlayer, playerIterator;
let humanPlayerIndex = 0;  // Human is player 1 (index 0)
let computerPlayerIndices = [1, 2];  // Computers are players 2 and 3

// Define ladders and snakes
const ladders = [{ startX: 1, startY: 0, endX: 4, endY: 3 }, { startX: 2, startY: 5, endX: 4, endY: 8 }];
const snakes = [{ startX: 0, startY: 7, endX: 0, endY: 3 }, { startX: 6, startY: 8, endX: 2, endY: 5 }];

//Player Class
class Player {
	constructor(x, y, id) {
		this.x = x;
		this.y = y;
		this.id = id;
	}

	getDomElement() {
		if (!this.dom) {
			this.dom = document.createElement("div");
			this.dom.classList.add("player");
			this.dom.style.backgroundColor = ["lightblue", "lightgray", "pink"][this.id - 1];
			this.dom.innerText = this.id;
		}
		return this.dom;
	}
}
//Game Initialization
function startGame() {
	players = [new Player(0, 0, 1), new Player(0, 0, 2), new Player(0, 0, 3)];
	playerIterator = cyclicIterator(players);
	currentPlayer = playerIterator.next().value;
	document.querySelector("#gameboard").hidden = false;
	document.querySelector("#welcome").hidden = true;
	document.getElementById("dice-results").innerText = `Player ${currentPlayer.idx + 1}'s turn`;
	document.getElementById("roll-dice").disabled = currentPlayer.idx !== humanPlayerIndex;
	renderBoard();
}

function* cyclicIterator(v) {
	let i = 0;
	while (true) yield { idx: i, value: v[i++ % v.length] };
}

//rollDice() simulates a dice roll. For the human player, the dice roll is random
async function rollDice() {
	let result = randIntv1(6) + 1;
	document.getElementById("dice-results").innerText = `Dice: ${result}`;
	document.getElementById("roll-dice").disabled = true;
	
	if (computerPlayerIndices.includes(currentPlayer.idx)) {
		result = computerChoice(currentPlayer.value);  // Use Minimax for computer
	}

	for (let i = 0; i < result; i++) {
		await new Promise(resolve => setTimeout(resolve, 200));
		movePlayer(currentPlayer.value);
		if (checkWin(currentPlayer)) return;
	}

	checkLadder(currentPlayer.value);
	checkSnakes(currentPlayer.value);
	currentPlayer = playerIterator.next().value;

	if (computerPlayerIndices.includes(currentPlayer.idx)) {
		await new Promise(resolve => setTimeout(resolve, 500));
		await rollDice();
	} else {
		document.getElementById("roll-dice").disabled = false;
		document.getElementById("dice-results").innerText = `Player ${currentPlayer.idx + 1}'s turn`;
	}
}
//Player Movement
//moves a player horizontally across the row 
function movePlayer(player) {
	player.x = player.y % 2 === 0 ? Math.min(player.x + 1, width - 1) : Math.max(player.x - 1, 0);
	player.y += player.x === (player.y % 2 === 0 ? width - 1 : 0) ? 1 : 0;
	renderBoard();
}


//check if a player lands on the start of a ladder or a snake. If they do, they "jump" to the end of the ladder or snake.
function checkLadder(player) {
	ladders.forEach(ladder => {
		if (ladder.startX === player.x && ladder.startY === player.y) {
			player.x = ladder.endX;
			player.y = ladder.endY;
			renderBoard();
		}
	});
}

function checkSnakes(player) {
	snakes.forEach(snake => {
		if (snake.startX === player.x && snake.startY === player.y) {
			player.x = snake.endX;
			player.y = snake.endY;
			renderBoard();
		}
	});
}

//hecks if a player reaches the top-right corner (the final tile) and declares them the winner.
function checkWin(data) {
	const { x, y } = data.value;
	if ((y === height - 1 && x === (width % 2 ? 0 : width - 1))) {
		document.getElementById("win").hidden = false;
		document.getElementById("win-text").innerText = `Player ${data.idx + 1} wins!`;
		return true;
	}
	return false;
}
//Computer Decision-Making
function computerChoice(player) {
	// Basic Minimax decision-making: Prefer ladders, avoid snakes
	let bestMove = 1;
	let bestScore = -Infinity;
	
	for (let move = 1; move <= 6; move++) {
		const { newX, newY } = simulateMove(player, move);
		const score = evaluatePosition(newX, newY);
		
		if (score > bestScore) {
			bestScore = score;
			bestMove = move;
		}
	}
	return bestMove;
}

function simulateMove(player, move) {
	let x = player.x, y = player.y;
	for (let i = 0; i < move; i++) {
		x = y % 2 === 0 ? Math.min(x + 1, width - 1) : Math.max(x - 1, 0);
		y += x === (y % 2 === 0 ? width - 1 : 0) ? 1 : 0;
	}
	return { newX: x, newY: y };
}

function evaluatePosition(x, y) {
	let score = y * width + (y % 2 ? width - x : x);  // Higher is better
	ladders.forEach(l => (l.startX === x && l.startY === y) && (score += 10));
	snakes.forEach(s => (s.startX === x && s.startY === y) && (score -= 10));
	return score;
}

//updates the visual game board on the page, placing each player in their current position.
function renderBoard() {
	const board = document.getElementById("board");
	board.innerHTML = "";
	for (let y = 0; y < height; y++) {
		for (let x = 0; x < width; x++) {
			const tile = document.createElement("div");
			tile.classList.add("tile");
			players.forEach(player => {
				if (player.x === x && player.y === y) tile.appendChild(player.getDomElement());
			});
			board.appendChild(tile);
		}
	}
}

function randIntv1(x) //generates a random number for the human player's dice rol
 {
	return Math.floor(Math.random() * x);
}
